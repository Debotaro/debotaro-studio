# Northstar Support

Independent React/TypeScript application exported from Debotaro Studio, revision 0. All tickets and customers are fictional. The application uses its own local runtime state and does not connect to Studio or a live support system.

## Run

Use Node.js 24.13 or newer and npm.

```sh
npm ci
npm run typecheck
npm run build
npm run dev
```

Open the Vite URL printed by the terminal. For the built application, run `npm run preview`. Direct and transitive dependency versions/integrities are pinned in package.json and package-lock.json.

## Verify behavior

Search for a fictional subject or customer, filter status and assignee, select a ticket, change its assignment/status, and clear filters to recover the full list. Resize to desktop, tablet and phone widths. Loading/retry/empty/error behavior is supplied by the same catalog runtime used by Studio. Refresh resets local ticket interactions to the exported initial document.

## Source and boundaries

- src/App.tsx contains runnable catalog TSX generated from the validated document.
- src/runtime is the shared component implementation and fictional connector.
- src/core/types.ts and tokens.ts contain the runtime contract and token resolver.
- studio-document.json and tokens.json preserve the intermediate representation and theme references.
- recovery files, when present, preserve the original Studio code and outside managed source as plain text. They are intentionally excluded from executable files. Review and integrate handwritten code yourself in a trusted development workflow.

This export requires no account, API key, Studio server or paid service. Live customer connections can implement the TicketConnector contract in src/runtime/connector.ts.

## Attribution

Debotaro Studio is an independent product by Debotaro, inspired by professional creation-tool workflows. React, TypeScript and Vite are third-party dependencies with their own licenses. No third-party image/font assets are required.
