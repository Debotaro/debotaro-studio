import type { StudioDocument } from './core/types';
import { StudioProvider, Frame, Text, Button, Field, Select, Tabs, Badge, Table, DetailPanel } from './runtime/StudioRuntime';

// @studio:begin
export const studioMeta: Omit<StudioDocument, "nodes"> = {
  "data": {
    "tickets": [
      {
        "assignee": "Alex Morgan",
        "company": "Northstar Paper Co.",
        "customer": "Maya Chen",
        "email": "maya@northstar.example",
        "id": "TK-1042",
        "message": "Hello! We are preparing our next workshop and would love to invite twelve teammates. Could you help us understand the team invitation flow?",
        "priority": "high",
        "status": "open",
        "subject": "Can we invite our whole team?",
        "updatedAt": "2026-10-14T09:40:00Z"
      },
      {
        "assignee": "Jordan Ellis",
        "company": "Juniper Works",
        "customer": "Sam Rivera",
        "email": "sam@juniper.example",
        "id": "TK-1041",
        "message": "Our finance team needs the billing contact shown on our next invoice. Where can we update that information? Thank you for your help.",
        "priority": "normal",
        "status": "pending",
        "subject": "A quick question about invoices",
        "updatedAt": "2026-10-14T09:12:00Z"
      },
      {
        "assignee": "Alex Morgan",
        "company": "Plainlight Studio",
        "customer": "Noor Patel",
        "email": "noor@plainlight.example",
        "id": "TK-1040",
        "message": "I saved a view for our weekly review, but one of the columns is missing when I reopen it. I am using the desktop browser.",
        "priority": "normal",
        "status": "open",
        "subject": "My saved view looks different",
        "updatedAt": "2026-10-14T08:55:00Z"
      },
      {
        "assignee": "Taylor Reed",
        "company": "Fable Supply",
        "customer": "Ellis Park",
        "email": "ellis@fable.example",
        "id": "TK-1039",
        "message": "The onboarding steps worked perfectly. Our first project is ready, and everyone can sign in. Thanks for the thoughtful guidance!",
        "priority": "low",
        "status": "resolved",
        "subject": "Thanks for the onboarding help",
        "updatedAt": "2026-10-14T08:30:00Z"
      },
      {
        "assignee": "",
        "company": "Small Hours",
        "customer": "Ari Okafor",
        "email": "ari@smallhours.example",
        "id": "TK-1038",
        "message": "We want to share a project with a teammate who does not have an account yet. Is there an export we can send for a local review?",
        "priority": "high",
        "status": "open",
        "subject": "Exporting a project for review",
        "updatedAt": "2026-10-14T08:05:00Z"
      },
      {
        "assignee": "Jordan Ellis",
        "company": "Branchline Goods",
        "customer": "Robin Wells",
        "email": "robin@branchline.example",
        "id": "TK-1037",
        "message": "Our studio has a new name. Could you point us to the workspace settings so we can update it for everyone?",
        "priority": "low",
        "status": "pending",
        "subject": "Changing our workspace name",
        "updatedAt": "2026-10-14T07:45:00Z"
      }
    ]
  },
  "id": "debotaro-verified-export-example",
  "initialState": {
    "assignee": "all",
    "query": "",
    "selectedTicketId": "TK-1042",
    "status": "all",
    "tab": "inbox"
  },
  "name": "Northstar Support",
  "revision": 0,
  "rootId": "workspace",
  "schemaVersion": 1,
  "theme": "light",
  "tokens": {
    "primitive": {
      "canvas": "#f5f6fa",
      "exportGap": 24,
      "exportPhonePadding": 12,
      "exportTitle": 28,
      "exportWeight": 700,
      "green": "#23734e",
      "ink": "#18202f",
      "line": "#e4e7ef",
      "muted": "#657084",
      "night": "#171a24",
      "nightLine": "#383e51",
      "nightMuted": "#acb4c7",
      "nightSurface": "#222635",
      "nightText": "#f2f4fa",
      "radius": 12,
      "space": 8,
      "violet": "#6d4aff",
      "violetSoft": "#f0ecff",
      "white": "#ffffff"
    },
    "semantic": {
      "accent": "$primitive.violet",
      "accentSoft": "$primitive.violetSoft",
      "background": "$primitive.canvas",
      "border": "$primitive.line",
      "exportGap": "$primitive.exportGap",
      "exportTitle": "$primitive.exportTitle",
      "exportWeight": "$primitive.exportWeight",
      "muted": "$primitive.muted",
      "onAccent": "$primitive.white",
      "success": "$primitive.green",
      "surface": "$primitive.white",
      "text": "$primitive.ink"
    }
  }
};

export function StudioApp() {
  return (
    <StudioProvider meta={studioMeta}>
      <Frame studioId={"workspace"} name={"Support workspace"} props={{"background":"$semantic.background","radius":"$primitive.radius"}} layout={{"direction":"column","display":"flex","gap":"$semantic.exportGap","height":"auto","padding":"$primitive.exportGap","width":"fill"}} responsive={{"phone":{"gap":16,"padding":"$primitive.exportPhonePadding"},"tablet":{"gap":20,"padding":24}}} bindings={{}} events={{}}>
        <Frame studioId={"workspace-header"} name={"Workspace heading"} props={{"background":"transparent"}} layout={{"align":"center","direction":"row","display":"flex","gap":16,"justify":"between"}} responsive={{"phone":{"align":"stretch","direction":"column","gap":12}}} bindings={{}} events={{}}>
          <Frame studioId={"heading-copy"} name={"Heading copy"} props={{"background":"transparent"}} layout={{"direction":"column","display":"flex","gap":6}} responsive={{}} bindings={{}} events={{}}>
            <Text studioId={"workspace-eyebrow"} name={"Workspace label"} props={{"color":"$semantic.accent","size":12,"text":"NORTHSTAR · CUSTOMER CARE","variant":"eyebrow","weight":700}} layout={{}} responsive={{}} bindings={{}} events={{}} />
            <Text studioId={"workspace-title"} name={"Inbox heading"} props={{"color":"$semantic.text","size":"$semantic.exportTitle","text":"A little care goes a long way.","variant":"title","weight":"$semantic.exportWeight"}} layout={{}} responsive={{"phone":{"width":"fill"}}} bindings={{}} events={{}} />
            <Text studioId={"workspace-description"} name={"Inbox description"} props={{"color":"$semantic.muted","size":14,"text":"A thoughtful place to help your customers move forward.","variant":"body","weight":400}} layout={{}} responsive={{}} bindings={{}} events={{}} />
          </Frame>
          <Button studioId={"refresh-tickets"} name={"Refresh tickets"} props={{"disabled":false,"label":"Refresh inbox","variant":"secondary"}} layout={{}} responsive={{}} bindings={{}} events={{"onClick":{"action":"reloadTickets"}}} />
        </Frame>
        <Tabs studioId={"workspace-views"} name={"Workspace views"} props={{"label":"Workspace views","options":[{"label":"Inbox","value":"inbox"},{"label":"Activity","value":"activity"}]}} layout={{}} responsive={{}} bindings={{"value":"tab"}} events={{"onChange":{"action":"setTab"}}} />
        <Frame studioId={"workspace-content"} name={"Inbox and ticket details"} props={{"background":"transparent"}} layout={{"align":"start","direction":"row","display":"flex","gap":20,"width":"fill"}} responsive={{"phone":{"align":"stretch","direction":"column","gap":16},"tablet":{"align":"stretch","direction":"column"}}} bindings={{}} events={{}}>
          <Frame studioId={"inbox-panel"} name={"Inbox panel"} props={{"background":"$semantic.surface","border":"$semantic.border","radius":14,"shadow":"soft"}} layout={{"direction":"column","display":"flex","gap":18,"grow":1,"padding":20,"width":"fill"}} responsive={{"phone":{"gap":14,"padding":14}}} bindings={{}} events={{}}>
            <Frame studioId={"inbox-header"} name={"Inbox panel heading"} props={{"background":"transparent"}} layout={{"align":"center","direction":"row","display":"flex","gap":8,"justify":"between"}} responsive={{}} bindings={{}} events={{}}>
              <Text studioId={"inbox-title"} name={"Ticket list heading"} props={{"color":"$semantic.text","size":18,"text":"Your team inbox","variant":"title","weight":600}} layout={{}} responsive={{}} bindings={{}} events={{}} />
              <Badge studioId={"demo-badge"} name={"Fictional data badge"} props={{"label":"Demo workspace","tone":"accent"}} layout={{}} responsive={{}} bindings={{}} events={{}} />
            </Frame>
            <Frame studioId={"inbox-filters"} name={"Search and filters"} props={{"background":"transparent"}} layout={{"align":"end","columns":3,"display":"grid","gap":12,"width":"fill"}} responsive={{"phone":{"columns":1,"gap":10},"tablet":{"columns":3}}} bindings={{}} events={{}}>
              <Field studioId={"ticket-search"} name={"Search tickets"} props={{"disabled":false,"label":"Search tickets","placeholder":"Subject, name or email…","required":false,"type":"search"}} layout={{}} responsive={{}} bindings={{"value":"query"}} events={{"onChange":{"action":"setQuery"}}} />
              <Select studioId={"status-filter"} name={"Filter by status"} props={{"disabled":false,"label":"Status","options":[{"label":"All statuses","value":"all"},{"label":"Open","value":"open"},{"label":"Pending","value":"pending"},{"label":"Resolved","value":"resolved"}]}} layout={{}} responsive={{}} bindings={{"value":"status"}} events={{"onChange":{"action":"setStatus"}}} />
              <Select studioId={"assignee-filter"} name={"Filter by teammate"} props={{"disabled":false,"label":"Assignee","options":[{"label":"Anyone","value":"all"},{"label":"Unassigned","value":""},{"label":"Alex Morgan","value":"Alex Morgan"},{"label":"Jordan Ellis","value":"Jordan Ellis"},{"label":"Taylor Reed","value":"Taylor Reed"}]}} layout={{}} responsive={{}} bindings={{"value":"assignee"}} events={{"onChange":{"action":"setAssigneeFilter"}}} />
            </Frame>
            <Table studioId={"ticket-table"} name={"Fictional ticket table"} props={{"columns":["subject","customer","status","assignee"],"emptyMessage":"No tickets match. Try another search or clear your filters.","label":"Customer support tickets"}} layout={{"width":"fill"}} responsive={{}} bindings={{"value":"selectedTicketId"}} events={{"onClick":{"action":"selectTicket"}}} />
          </Frame>
          <DetailPanel studioId={"ticket-details"} name={"Ticket details"} props={{"background":"$semantic.surface","radius":14,"subtitle":"Give every conversation a little attention.","title":"Ticket details"}} layout={{"width":336}} responsive={{"phone":{"width":"fill"},"tablet":{"width":"fill"}}} bindings={{}} events={{}} />
        </Frame>
        <Text studioId={"fictional-notice"} name={"Fictional data disclosure"} props={{"color":"$semantic.muted","size":12,"text":"Fictional people and tickets · Changes stay in this local preview.","variant":"caption","weight":400}} layout={{}} responsive={{}} bindings={{}} events={{}} />
      </Frame>
    </StudioProvider>
  );
}
// @studio:end

export default StudioApp;
